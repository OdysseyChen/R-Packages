chensum <- function(vector) {
  s=0
  for(i in 1:length(vector))
  {
    s=s+vector[i]
  }
  return(s)
}
