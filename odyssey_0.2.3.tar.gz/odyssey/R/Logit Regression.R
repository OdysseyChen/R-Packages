#' Use logit regression to classify the data
#'
#' @param dataset A dataset
#' @param Y The response variable
#' @param p The Threshold of classify
#' @return The confusion matrix of the model
Logit<-function(dataset,Y,p)
{
  #划分训练集与测试集
  m=nrow(dataset)
  ind<-sample(2,m,replace=TRUE,prob = c(0.7,0.3))#抽取指标集
  traindata<-dataset[ind==1,]
  testdata<-dataset[ind==2,]
  #建模
  library(glm)
  data.glm<-glm(Y~.,data=traindata,family = binomial(link = "logit"))
  #求出预测值
  predict0<-predict(data.glm,newdata = testdata,type = "response")
  predict0#预测出来的是概率
  predict<-ifelse(predict0>p,1,0)#概率大于0.5就赋值为1，否则为0
  testdata$predict<-predict
  real<-testdata$Y
  #模型精度
  error<-predict-real
  #模型正确预测的数量占测试集的比例
  accuracy<- 1-sum(abs(error))/nrow(testdata)
  #Confusion Matrix
  confusion<-table(predict,real)
  return(confusion)
}
