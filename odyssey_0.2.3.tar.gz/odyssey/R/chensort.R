chensort<-function(a)
{
  n=length(a)
  for(i in 1:(n-1))
  {
    for(j in (i+1):n)
    {
      if(a[i]>a[j])
      {
        temp=a[i]
        a[i]=a[j]
        a[j]=temp
      }
    }
  }
  return(a)
}
#例子
a=c(1,3,6,4,2,8,5,2)
chensort(a)
