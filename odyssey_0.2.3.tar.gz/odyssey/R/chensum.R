#' Add all the numbers in a vector
#'
#' @param array An array
#' @return The Sum of the numbers in the input \code{array}
#' @example
#' chensum(c(1,2,3,4))
chensum <- function(array) {
  s=0
  for(i in 1:length(array))
  {
    s=s+array[i]
  }
  return(s)
}

chensum(c(1,2,3,4))
