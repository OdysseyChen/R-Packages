#' Use bootstrap to cross validate liner regression model
#'
#' @param dataset A dataset
#' @param n Bootstrap times
#' @param Y The response variable
#' @example
#' boostrap(iris,100,Petal.Length)
bootstrap<-function(dataset,n,Y)
{
  SSE<-matrix(0,nrow = 1,ncol = n)
      for(i in 1:n)
      {
        ind<-sample(1:nrow(dataset),nrow(dataset),replace = TRUE)
        train<-dataset[ind,]
        test<-dataset[-ind,]
        lmtrain<-lm(Y~.,data = train)
        predict<-predict(lmtrain,newdata=test,type="response")
        sse<-(predict-test$Y)^2
        SSE[1,i]<-sse
      }
      return(SSE)
}
